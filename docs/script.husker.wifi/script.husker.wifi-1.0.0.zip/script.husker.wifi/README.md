# Wi-Fi manager 1.0.0

Open **Programs → Wi-Fi manager**, or the **Wi-Fi manager** favourite.

Shows the connected network, Wi-Fi IP address, signal in dBm and negotiated
wireless link rate in Mbps. A less negative dBm value means a stronger signal.
Link rate is not measured internet throughput. Choose **Scan and connect** to
choose a visible network and enter a masked password. Failed connections offer
another password attempt and restore the previous connection where available.
**Change current Wi-Fi password** lets you replace a saved incorrect password.
Cancel a password dialog to leave it unchanged. Refresh updates the readings.

Supports open, WPA/WPA2 Personal and WPA3 SAE networks on Linux with
wpa_supplicant and Netplan. Enterprise, WEP and hidden networks are not supported.
Uses the first wireless adapter. Successful connections replace that adapter's
Netplan access-point list, leaving Ethernet and other interface settings intact.
Original Netplan files are backed up, root-only, in `/var/backups/husker-wifi/`.
Passwords are sent through a local socket, never shell arguments or addon settings.
Netplan stores the saved credentials in root-only configuration files.

## Administrator setup

Installing the Kodi ZIP alone cannot grant control of the host's networking.
Review and run `sudo sh setup/install.sh` on the host. Requires Python 3,
python3-yaml, Netplan, systemd and wpa_supplicant. The supplied setup targets
the Linux account `kodi`, home `/home/kodi`, with Kodi data at `~/.kodi`.
Adjust the unit and sudoers account for another installation before running it.
The helper is copied to `/usr/local/sbin/husker-wifi`, owned by root, and is
not automatically updated from Kodi's writable add-on directory.

The socket is private to the kodi account. Kodi Flatpak accesses it through its
existing profile directory, without granting general host-command access.
Native Kodi can also use the restricted, no-arguments sudo helper.

To remove host integration: stop/disable `husker-wifi.socket`, remove its socket
and service unit, `/etc/sudoers.d/husker-wifi`, and `/usr/local/sbin/husker-wifi`,
then reload systemd. Keep the saved Netplan configuration and backups as needed.

## Tinybox validation — 18 October 2026

Installed and enabled on Tinybox's Kodi Flatpak; favourite added; actual Kodi
selection dialog confirmed. Live status and scanning passed. A deliberate wrong
WPA2 password was rejected and the original network restored. Reconnecting with
the existing correct password passed, including Netplan generation and DHCP IP.
Parser and timeout/restoration checks also passed. WPA3, other access points and
persistence after an actual reboot have not been tested.
