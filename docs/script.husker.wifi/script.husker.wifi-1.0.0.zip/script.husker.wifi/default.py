import json
import subprocess
import socket
from pathlib import Path
import xbmcgui
import xbmcvfs

TITLE = 'Wi-Fi manager'
dialog = xbmcgui.Dialog()


def call(action, **values):
    try:
        endpoint = Path(xbmcvfs.translatePath('special://profile/husker-wifi.sock'))
        if endpoint.exists():
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(65)
                client.connect(str(endpoint))
                client.sendall(json.dumps(dict(action=action, **values)).encode())
                client.shutdown(socket.SHUT_WR)
                chunks = []
                while True:
                    chunk = client.recv(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                data = json.loads(b''.join(chunks))
                if 'error' in data:
                    raise RuntimeError(data['error'])
                return data
        result = subprocess.run(['sudo', '-n', '/usr/local/sbin/husker-wifi'],
                                input=json.dumps(dict(action=action, **values)),
                                text=True, capture_output=True, timeout=65)
        if result.returncode:
            raise RuntimeError('Wi-Fi helper unavailable. Ask an administrator to install the helper from this add-on’s setup folder.')
        data = json.loads(result.stdout)
        if 'error' in data:
            raise RuntimeError(data['error'])
        return data
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        raise RuntimeError('Cannot communicate with the Wi-Fi helper.') from error


def connect(network):
    if 'EAP' in network['flags'] or 'WEP' in network['flags']:
        dialog.ok(TITLE, 'Enterprise and WEP networks are not supported.')
        return
    secure = 'PSK' in network['flags'] or 'SAE' in network['flags']
    while True:
        password = dialog.input('Password for ' + network['ssid'], type=xbmcgui.INPUT_ALPHANUM,
                                option=xbmcgui.ALPHANUM_HIDE_INPUT) if secure else ''
        if secure and not password:
            return
        progress = xbmcgui.DialogProgress()
        progress.create(TITLE, 'Connecting to ' + network['ssid'] + '…')
        try:
            result = call('connect', ssid=network['ssid'], password=password, flags=network['flags'])
        except RuntimeError as error:
            result = {'ok': False, 'message': str(error)}
        finally:
            password = None
            progress.close()
        if result['ok']:
            dialog.ok(TITLE, result['message'])
            return
        if not dialog.yesno(TITLE, result['message'] + '\nEnter a different password and retry?', yeslabel='Retry'):
            return


def main():
    while True:
        data = call('status')
        status = data['status']
        signal = data['signal']
        heading = '{} | IP {} | {} Mbps | {} dBm'.format(
            status.get('ssid', 'Disconnected'), status.get('ip_address', '—'),
            signal.get('LINKSPEED', '—'), signal.get('RSSI', '—'))
        choice = dialog.select(heading, ['Connection details', 'Scan and connect', 'Change current Wi-Fi password', 'Refresh'])
        if choice < 0:
            return
        if choice == 0:
            dialog.ok(TITLE, 'Network: {}\nState: {}\nWi-Fi IP: {}\nSignal: {} dBm\nWireless link speed: {} Mbps\nLink speed is not an internet speed test.'.format(
                status.get('ssid', '—'), status.get('wpa_state', '—'), status.get('ip_address', '—'),
                signal.get('RSSI', '—'), signal.get('LINKSPEED', '—')))
        elif choice in (1, 2):
            networks = call('scan')['networks']
            if choice == 2:
                networks = [n for n in networks if n['ssid'] == status.get('ssid')]
            if not networks:
                dialog.ok(TITLE, 'No matching networks found. Refresh and try again.')
                continue
            selected = 0 if choice == 2 else dialog.select('Available Wi-Fi networks', [
                '{} | {} dBm | {}'.format(n['ssid'], n['signal'], n['flags']) for n in networks])
            if selected >= 0:
                connect(networks[selected])


if __name__ == '__main__':
    try:
        main()
    except RuntimeError as error:
        dialog.ok(TITLE, str(error))
