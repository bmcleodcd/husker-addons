import json
import subprocess
import socket
from pathlib import Path
import xbmcgui
import xbmcvfs
import xbmc
import xbmcaddon
import threading
import queue

TITLE = 'Wi-Fi manager'
dialog = xbmcgui.Dialog()


def call(action, **values):
    try:
        endpoint = Path(xbmcvfs.translatePath('special://profile/husker-wifi.sock'))
        if endpoint.exists():
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(65)
                client.connect(str(endpoint))
                client.sendall(json.dumps(dict(action=action, **values)).encode())
                client.shutdown(socket.SHUT_WR)
                chunks = []
                while True:
                    chunk = client.recv(65536)
                    if not chunk:
                        break
                    chunks.append(chunk)
                data = json.loads(b''.join(chunks))
                if 'error' in data:
                    raise RuntimeError(data['error'])
                return data
        result = subprocess.run(['sudo', '-n', '/usr/local/sbin/husker-wifi'],
                                input=json.dumps(dict(action=action, **values)),
                                text=True, capture_output=True, timeout=65)
        if result.returncode:
            raise RuntimeError('Wi-Fi helper unavailable. Ask an administrator to install the helper from this add-on’s setup folder.')
        data = json.loads(result.stdout)
        if 'error' in data:
            raise RuntimeError(data['error'])
        return data
    except (OSError, ValueError, subprocess.TimeoutExpired) as error:
        raise RuntimeError('Cannot communicate with the Wi-Fi helper.') from error


class WifiWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args):
        super().__init__(*args)
        self.pending = queue.Queue()
        self.busy = False
        self.closed = False
        self.ready = False
        self.networks = []
        self.selected = None
        self.password = ''
        self.visible_password = False
        self.current_ssid = None

    def onInit(self):
        self.ready = True
        self.setFocusId(20)
        self.start('Reading connection status…', lambda: call('status'), self.show_status)

    def message(self, text):
        self.getControl(12).setText(text)

    def start(self, message, operation, complete):
        if self.busy or self.closed:
            return
        self.busy = True
        self.message(message)
        for control in (20, 21, 22, 23, 24, 30):
            self.getControl(control).setEnabled(False)
        def worker():
            try:
                result = operation()
                self.pending.put((complete, result, None))
            except Exception as error:
                self.pending.put((complete, None, str(error)))
        threading.Thread(target=worker, daemon=True).start()

    def tick(self):
        try:
            complete, result, error = self.pending.get_nowait()
        except queue.Empty:
            return
        if self.closed:
            return
        self.busy = False
        for control in (20, 21, 22, 23, 24, 30):
            self.getControl(control).setEnabled(True)
        if error:
            self.message(error)
        else:
            complete(result)
        if not self.busy and self.getFocusId() not in (20, 21, 22, 23, 24, 25, 30):
            self.setFocusId(20)

    def show_status(self, data):
        status, signal = data['status'], data['signal']
        self.current_ssid = status.get('ssid')
        self.getControl(11).setText('Network: {}   |   IP: {}\nSignal: {} dBm   |   Link speed: {} Mbps'.format(
            status.get('ssid', 'Disconnected'), status.get('ip_address', '—'),
            signal.get('RSSI', '—'), signal.get('LINKSPEED', '—')))
        if self.selected is None and self.current_ssid:
            self.selected = {'ssid': self.current_ssid}
            self.start('Loading saved Wi-Fi password…',
                       lambda: call('password', ssid=self.current_ssid), self.loaded_password)
        else:
            self.message('Ready. Select a network or scan for nearby Wi-Fi.')

    def loaded_password(self, result):
        self.password = result.get('password', '')
        self.visible_password = False
        self.render_password()
        self.message('Saved password loaded. Choose Show password to view it.' if self.password else
                     'No saved password for this network. Choose Edit password to enter one.')

    def render_password(self):
        name = self.selected['ssid'] if self.selected else 'Select a network'
        self.getControl(13).setLabel('Selected network: ' + name)
        value = self.password if self.visible_password else ('•' * min(len(self.password), 16))
        self.getControl(14).setText('Password: ' + (value or '(empty)'))
        self.getControl(23).setLabel('Hide password' if self.visible_password else 'Show password')

    def scanned(self, result):
        self.networks = result['networks']
        listing = self.getControl(30)
        listing.reset()
        listing.addItems([xbmcgui.ListItem(label='{}   |   {} dBm   |   {}'.format(
            n['ssid'], n['signal'], n['flags'])) for n in self.networks])
        self.message('Found {} networks. Select one to load its saved password.'.format(len(self.networks)))
        if self.networks:
            self.setFocusId(30)

    def connected(self, result):
        message = result['message']
        def refreshed(data):
            self.show_status(data)
            self.message(message + ('' if result['ok'] else '\nEdit the password, then choose Connect to retry.'))
        self.start('Updating connection details…', lambda: call('status'), refreshed)

    def onClick(self, control):
        if control == 25:
            self.finish()
            return
        if self.busy:
            return
        if control == 20:
            self.start('Scanning nearby Wi-Fi networks…', lambda: call('scan'), self.scanned)
        elif control == 21:
            self.start('Refreshing connection details…', lambda: call('status'), self.show_status)
        elif control == 30:
            index = self.getControl(30).getSelectedPosition()
            if 0 <= index < len(self.networks):
                self.selected = self.networks[index]
                self.password = ''
                self.visible_password = False
                self.render_password()
                ssid = self.selected['ssid']
                self.start('Loading saved password for ' + ssid + '…',
                           lambda: call('password', ssid=ssid), self.loaded_password)
        elif control == 22 and self.selected:
            keyboard = xbmc.Keyboard(self.password, 'Password for ' + self.selected['ssid'], True)
            keyboard.doModal()
            if keyboard.isConfirmed():
                self.password = keyboard.getText()
                self.render_password()
                self.message('Password updated here. Choose Connect to apply it.')
        elif control == 23:
            self.visible_password = not self.visible_password
            self.render_password()
        elif control == 24 and self.selected:
            ssid, password = self.selected['ssid'], self.password
            self.start('Connecting to ' + ssid + '… Checking password and waiting for the connection.',
                       lambda: call('connect', ssid=ssid, password=password), self.connected)

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.finish()

    def finish(self):
        if self.busy:
            self.message('Please wait for the current Wi-Fi operation to finish…')
            return
        self.password = ''
        self.visible_password = False
        if self.ready:
            self.getControl(14).setText('')
        self.closed = True
        self.close()


def main():
    addon = xbmcaddon.Addon()
    window = WifiWindow('wifi.xml', addon.getAddonInfo('path'), 'Default', '720p')
    window.show()
    monitor = xbmc.Monitor()
    try:
        while not window.closed and not monitor.waitForAbort(0.1):
            if window.ready:
                window.tick()
    finally:
        window.password = ''
        window.close()
        del window


if __name__ == '__main__':
    main()
